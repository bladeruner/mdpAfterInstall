--------------------
mdpAfterInstall
--------------------
Author: Kirill Korovin <coder@brightweb.ru>
--------------------

MODX after install tool to set system values and SEO strict url.